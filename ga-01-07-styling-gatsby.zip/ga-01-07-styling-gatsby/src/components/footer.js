import React from 'react'

const Footer = () => {
    return (
        <footer>
            <p>Created by Andrew Mead, © 2019</p>
        </footer>
    )
}

export default Footer