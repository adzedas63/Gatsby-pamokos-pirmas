import React from "react"

export default () => <div>The Great Gatsby Bootcamp</div>
