import React from 'react'

const IndexPage = () => {
    return (
        <div>
            <h1>Hello.</h1>
            <h2>I'm Andrew, a full-stack developer living in beautiful Philadelphia.</h2>
        </div>
    )
}

export default IndexPage