import React from 'react'

const ContactPage = () => {
    return (
        <div>
            <h1>Contact</h1>
            <p>The best way to reach me is via @andrew_j_mead on Twitter!</p>
        </div>
    )
}

export default ContactPage