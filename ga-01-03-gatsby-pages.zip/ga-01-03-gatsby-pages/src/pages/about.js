import React from 'react'

const AboutPage = () => {
    return (
        <div>
            <h1>About Me</h1>
            <p>I currently teach full-time on Udemy.</p>
        </div>
    )
}

export default AboutPage