import React from 'react'

import Layout from '../components/layout'

const Blog = () => {
    return (
        <Layout>
            This is the blog template
        </Layout>
    )
}

export default Blog